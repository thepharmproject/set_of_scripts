import tweepy
from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener
import time
import argparse
import string
#import config
import json
import csv
#import xlsxwriter
import re
import datetime


# authorization tokens
consumer_key = 'bk7wn33YtsA2W2HTtP9o6yr26'
consumer_secret = 'YougqBSBRFpg9CdBbTBCDCJLD3brZKojMzUDfB6nvsc5PJ0p5B'
access_key = '955766670135644160-CqYMwTNxsiDBIikR8lhfaZUb6wxUiU8'
access_secret = 'CWAUOPLt81NktT9hZaoIcWAuMmy2XxVmB8WVXyzrlJ8hj'

# StreamListener class inherits from tweepy.StreamListener and overrides on_status/on_error methods.
class StreamListener(tweepy.StreamListener):
    def on_status(self, status):
        #print(status.id_str)
        # if "retweeted_status" attribute exists, flag this tweet as a retweet.
        is_retweet = hasattr(status, "retweeted_status")

        # check if text has been truncated
        if hasattr(status,"extended_tweet"):
            text = status.extended_tweet["full_text"]
        else:
            text = status.text

        # check if this is a quote tweet.
        is_quote = hasattr(status, "quoted_status")
        quoted_text = ""
        if is_quote:
            # check if quoted tweet's text has been truncated before recording it
            if hasattr(status.quoted_status,"extended_tweet"):
                quoted_text = status.quoted_status.extended_tweet["full_text"]
            else:
                quoted_text = status.quoted_status.text


        # Happy Emoticons
        emoticons_happy = set([':-)', ':)', ';)', ':o)', ':]', ':3', ':c)', ':>', '=]', '8)', '=)', ':}',':^)', ':-D', ':D', '8-D', '8D', 'x-D', 'xD', 'X-D', 'XD', '=-D', '=D','=-3', '=3', ':-))', ":'-)", ":')", ':*', ':^*', '>:P', ':-P', ':P', 'X-P','x-p', 'xp', 'XP', ':-p', ':p', '=p', ':-b', ':b', '>:)','>;)', '>:-)','<3'])
	
        # Sad Emoticons
        emoticons_sad = set([':L', ':-/', '>:/', ':S', '>:[', ':@', ':-(', ':[', ':-||', '=L', ':<',':-[', ':-<', '=\\', '=/', '>:(', ':(', '>.<', ":'-(", ":'(", ':\\', ':-c',':c', ':{', '>:\\', ';('])


        #Emoji patterns
        emoji_pattern = re.compile("["
                           u"\U0001F600-\U0001F64F"  # emoticons
                           u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                           u"\U0001F680-\U0001F6FF"  # transport & map symbols
                           u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                           u"\U00002702-\U000027B0"
                           u"\U000024C2-\U0001F251"
                           "]+", flags=re.UNICODE)
	

        #combine sad and happy emoticons
        emoticons = emoticons_happy.union(emoticons_sad)	


	#after tweepy preprocessing the colon left remain after removing mentions
    	#or RT sign in the beginning of the tweet
        text= re.sub(r':', '', text)
        text = re.sub(r'‚Ä¶', '', text)
   	
 
    	#remove emojis from tweet
        text = emoji_pattern.sub(r'', text)
        quoted_text = emoji_pattern.sub(r'', quoted_text)

        # remove characters that might cause problems with csv encoding
        remove_characters = [",","\\n","\n"]
        for c in remove_characters:
            text.replace(c," ")
            quoted_text.replace(c, " ")

        print(text)

        #text = text.replace("\\n", " ").replace("\\r", " ")
        #text = text.encode("ascii", "strict").decode('unicode-escape', 'strict')
        #text = text.encode('utf-16', 'surrogatepass').decode('utf-16')

        with open("../Data/out.csv", "a", encoding='utf-8-sig') as f:
            firstfield=status.created_at
            #print(status.user.lang)
            if (type(firstfield) is datetime.datetime):
                #f.write("%s,%s,%s,%s,%s,%s\n" % (status.created_at,status.user.screen_name,is_retweet,is_quote,text,quoted_text))
                fieldnames=['date','tweet_id','is_retweet','is_quote','user_id','username','scr_name','location','followers','friends','text','quoted_text']
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writerow({'date':status.created_at, 'tweet_id':status.id, 'is_retweet':is_retweet, 'is_quote':is_quote, 'user_id':status.user.id, 'username':status.user.name,'scr_name':status.user.screen_name,'location':status.user.location,'followers':status.user.followers_count,'friends':status.user.friends_count, 'text':text, 'quoted_text':quoted_text })


    #def on_data(self,data):
        #try:
            #with open("out.json", 'a', encoding='utf-8-sig') as f:
                #f.write(data)
                #print(data)
                #return True
        #except BaseException as e:
            #print("Error on_data: %s" % str(e))
            #time.sleep(5)
        #return True

    def on_error(self, status_code):
        print("Encountered streaming error (", status_code, ")")
        sys.exit()

if __name__ == "__main__":
    # complete authorization and initialize API endpoint
    auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_key, access_secret)
    api = tweepy.API(auth)

    # initialize stream
    streamListener = StreamListener()
    stream = tweepy.Stream(auth=api.auth, listener=streamListener,tweet_mode='extended')
    with open("../Data/out.csv", "w", encoding='utf-8-sig') as f:
        f.write("date,tweet_id,is_retweet,is_quote,user_id,username,screen_name,location,followers,friends,text,quoted_text\n")
        #fieldnames=['date','user','is_retweet','is_quote','text','quoted_text']
        #writer = csv.DictWriter(f, fieldnames=fieldnames)
    tags = ["#μενουμε_ασφαλεις","#COVID19greece","#κορονοιος","#πανδημια","καραντίνα","#καραντίνα","#μμε_ξεφτίλες","#Τσιοδρας","πανδημία"]
    #tags = ["#μενουμε_ασφαλεις","#COVID19greece","#κορονοιος","#πανδημια","#καραντίνα","#μμε_ξεφτίλες","#Τσιοδρας"]
    stream.filter(track=tags)